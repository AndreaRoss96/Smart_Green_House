package events;

public class OvertimePump implements Event {

}
