package events;

/*Generated when the pump has to stop*/
public class DonePump implements Event {
	
}
