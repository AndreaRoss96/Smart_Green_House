package events;

public interface Event {

}
