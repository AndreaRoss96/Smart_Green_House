<?php
  echo file_get_contents( "../green_house_javaServer/JavaServer/log.txt" );
?>
